import axios from "axios";
import { useState } from "react";

function Login() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = () => {
        axios
            .post("http://localhost:8080/auth/signin", {
                email: username,
                password: password,
            })
            .then((res) => console.log(res))
            .catch((err) => console.log(err));
    };

    return (
        <div>
            <label htmlFor="">Username: <input type="text" name="userName" value={username} onChange={(e) => setUsername(e.target.value)} /></label>
            <label htmlFor="">Password: <input type="text" name="password" value={password} onChange={(e) => setPassword(e.target.value)} /></label>
            <input type="button" value="Login" onClick={handleLogin} />
        </div>
    );
}

export default Login;
